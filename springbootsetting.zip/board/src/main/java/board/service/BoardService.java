package board.service;

import java.util.List;

import board.dto.BoardDto;

public interface BoardService {
	// 게시판 목록 조회 기능을 정의
	List<BoardDto> selectBoardList() throws Exception;
}

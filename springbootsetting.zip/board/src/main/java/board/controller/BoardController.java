package board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import board.dto.BoardDto;
import board.service.BoardService;
@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;
	
	@RequestMapping("/board/openBoardList.do")
	public ModelAndView openBoardList() throws Exception {
		ModelAndView mv = new ModelAndView("board/boardList");
		List<BoardDto> list = boardService.selectBoardList();
		mv.addObject("list", list);
		
		System.out.println(list.get(0).getTitle()+"=list입니다");
		mv.addObject("my","dear");
		return mv;
	}
	 @GetMapping("/test")
	    public String study() {
		 System.out.println("testst입니다");
	        return "board/boardList";
	    }
	
}
